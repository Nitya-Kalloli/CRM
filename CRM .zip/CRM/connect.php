<?php 
$host = "localhost";
$user = "root";
$pass = "";
$db = "crm";
$con = mysqli_connect($host,$user, $pass,$db) or die("Connection failed");
?>